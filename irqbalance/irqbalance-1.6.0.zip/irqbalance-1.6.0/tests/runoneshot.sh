#!/bin/sh

exec ../irqbalance --debug --oneshot --foreground

